TorCOIN Wallet Requirements:
==============================

Minimum Requirements:
• Windows 10 or later
• Python 3.8 or higher
• 100 MB free disk space
• 512 MB RAM

Recommended:
• Windows 11
• Python 3.9+
• 1 GB RAM
• Fast internet connection

Installation:
1. Ensure Python is installed
2. Run: Run_TorCOIN_Wallet.bat
3. Optional: Create_Desktop_Shortcut.bat

For help, visit: https://www.torcoin.cnet/support
